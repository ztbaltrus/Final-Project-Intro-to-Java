/**Final Project: Account
 * CIS 2571
 * @author Zachary Baltrus
 * @version 27Jul2017
 */
public interface Account {
	//Interface with abstract methods
	public abstract String getAccountType();
	public abstract double getAccountBalance();
}
