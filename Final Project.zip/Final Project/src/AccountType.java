/**Final Project: AccountType
 * CIS 2571
 * @author Zachary Baltrus
 * @version 27Jul2017
 */
public class AccountType {
	//Full of final strings used to determine what account the user would like to access
	public static final String SAVINGS = "Savings";
	public static final String CHECKINGS = "Checkings";
	public static final String MORTGAGE = "Mortgage";
}
